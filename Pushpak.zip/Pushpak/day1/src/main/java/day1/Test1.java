package day1;
public class Test1 {
	public static long max(long first,long second)
	{
		if(second>first)
		{
			return second;
		}
	return first;
}
	
public static long MaxFromList(long[] array)
{
	long maxvalue=array[0];
	for(int i=0;i<array.length;i++)
	{
		maxvalue=Test1.max(maxvalue,i);
	}
	return maxvalue;
			
		}
	}

