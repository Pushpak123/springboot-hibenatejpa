import java.util.Iterator;
import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;


public class FetchTest {
	public static void main(String[] args) {
		Configuration cfg = new Configuration().configure()
				.addAnnotatedClass(Employee.class)
				.addAnnotatedClass(Address.class);
		
		ServiceRegistry sr = new StandardServiceRegistryBuilder()
				.applySettings(cfg.getProperties()).build();
		
		SessionFactory sf = cfg.buildSessionFactory(sr);
		Session session = sf.openSession();
		Query query=session.createQuery("from Employee");
		@SuppressWarnings("unchecked")
		List<Employee>list=query.getResultList();
		Iterator<Employee>itr=list.iterator();
		while(itr.hasNext())
		{
			Employee e=itr.next();
			System.out.println(e.getEid()+""+e.getName()+""+e.getEmail());
			Address a1=e.getAddress();
			System.out.println(a1.getAddressline()+""+a1.getCity()+""+a1.getState()+""+a1.getCountry()+""+a1.getPincode());
		}
			session.close();
			System.out.println("success");
		}
		
	}


