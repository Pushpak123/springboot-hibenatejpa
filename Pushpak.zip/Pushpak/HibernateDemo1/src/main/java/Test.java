import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;


public class Test {
	public static void main(String[] args) {

		Configuration cfg = new Configuration().configure()
				.addAnnotatedClass(Employee.class)
				.addAnnotatedClass(Address.class);
		
		ServiceRegistry sr = new StandardServiceRegistryBuilder()
				.applySettings(cfg.getProperties()).build();
		
		SessionFactory sf = cfg.buildSessionFactory(sr);
		Session session = sf.openSession();
		Transaction t = session.beginTransaction();
		Employee e1=new Employee();
		e1.setName("sam");
		e1.setEmail("sam@gmail.com");
		
		Address address1=new Address();
		address1.setAddressline("plot no.5");
		address1.setCity("Pune");
		address1.setState("Maharashtra");
		address1.setCountry("India");
        address1.setPincode(425004);
        e1.setAddress(address1);
        address1.setEmployee(e1);
        session.persist(e1);
        t.commit();
        session.close();
        System.out.println("success");
	}

}
