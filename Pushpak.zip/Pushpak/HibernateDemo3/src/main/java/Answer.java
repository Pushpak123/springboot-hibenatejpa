import javax.persistence.*;

@Entity
@Table(name="ans1123")
public class Answer {
	@Id
	 @GeneratedValue(strategy=GenerationType.AUTO)  
	private int id;
	private String aname;
	private String postedby;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getAname() {
		return aname;
	}
	public void setAname(String aname) {
		this.aname = aname;
	}
	public String getPostedby() {
		return postedby;
	}
	public void setPostedby(String postedby) {
		this.postedby = postedby;
	}
	
	

}
