import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="userDetails")
public class User {
@Id
@GeneratedValue(strategy=GenerationType.IDENTITY)
private int userid;
private String username;
@OneToOne(cascade=CascadeType.ALL)

private UserDetails userDetail;
public User(int userid,String username,UserDetails userDetail)
{
	this.userid=userid;
	this.username=username;
	this.userDetail=userDetail;
}
public User()
{
	
}
public int getUserid() {
	return userid;
}
public void setUserid(int userid) {
	this.userid = userid;
}
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public UserDetails getUserDetails() {
	return userDetail;
}
public void setUserDetails(UserDetails userDetails) {
	this.userDetail = userDetails;
}

}
