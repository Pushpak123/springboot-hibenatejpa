import org.hibernate.*;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
public class Test {
	public static void main(String[] args) {
		System.out.println("test");
		
		Transaction t=session.beginTransaction();
		Student s=new Student();
		s.setSid(1);
		s.setStudentName("dam1");
		session.save(s);
		
		t.commit();
		System.out.println("hello");
	}
//db start
	//config file db con info
	//config build add table entity
	//sessionfactory
	//session
	//transaction
	//crud logic
	//commit
}
