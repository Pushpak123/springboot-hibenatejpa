import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

public class HibernateUtil {
public static void main(String[] args) {
	
		Configuration cfg = new Configuration().configure().addAnnotatedClass(
				User.class);
		
		ServiceRegistry sr = new StandardServiceRegistryBuilder()
				.applySettings(cfg.getProperties()).build();
		
		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession();
		Transaction t = session.beginTransaction();
		
		User u = new User();
		u.setUsername("sam");
		
		UserDetails userDetails = new UserDetails();
		
		u.setUserDetails(userDetails);

		userDetails.setUsername("dam");
		userDetails.setUser(u);
		
	
		
		t.commit();
		session.close();

	}

}
