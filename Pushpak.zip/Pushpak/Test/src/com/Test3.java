package com;

public class Test3 {
	public static void main(String[] args) {
		int x=3;
		int y=4;
		if(x<3)
		{
		System.out.println("min val"+x);
		}
		else
		{
			System.out.println("max val"+y);
		}
		
	}

}
