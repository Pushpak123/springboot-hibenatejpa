package com;

public class Test2 {
	public static void main(String[] args) {
		int x=30;
		int y=20;
		System.out.println("before swap");
		System.out.println("x:"+x);
		System.out.println("y:"+y);
		x=x+y;
		y=x-y;
		x=x-y;
		System.out.println("after swap");
		System.out.println("x:"+x);
		System.out.println("y:"+y);
	}

}
