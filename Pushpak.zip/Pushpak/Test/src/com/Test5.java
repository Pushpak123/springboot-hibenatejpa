package com;

public class Test5 {
	public static void main(String[] args) {
		int arr[]={9,2,3,4,6,7};
		int largest=arr[0];
		int smallest=arr[0];
		int index=0;
		int small=0;
		for(int i=0;i<arr.length;i++)
		{
			if(arr[i]>largest)
			{
				largest=arr[i];
				System.out.println(index=1);
			}
			else if(arr[i]<smallest)
			{
				smallest=arr[i];
				System.out.println(small=1);
			}
			System.out.println("largest:"+largest);
			System.out.println("index"+index);
			System.out.println("smallest"+smallest);
			System.out.println("small"+small);
			}
		}
	}

