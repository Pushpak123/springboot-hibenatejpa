package com;

public class Test4 {
	public static void main(String[] args) {
		int arr[]={2,3,4,5,6};
		for(int i=0;i<arr.length;i++)
		{
			System.out.println(""+arr[i]);
		}
	}

}
