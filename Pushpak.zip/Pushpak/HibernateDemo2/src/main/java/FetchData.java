import java.util.Iterator;
import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;


public class FetchData {
	public static void main(String[] args) {
		
	Configuration cfg = new Configuration().configure()
			.addAnnotatedClass(Question.class)
			.addAnnotatedClass(Answer.class);
	
	ServiceRegistry sr = new StandardServiceRegistryBuilder()
			.applySettings(cfg.getProperties()).build();
	
	SessionFactory sf = cfg.buildSessionFactory(sr);
	Session session = sf.openSession();
	Query query=session.createQuery("from Question");
	@SuppressWarnings("unchecked")
	List<Question>list1=query.getResultList();
	Iterator<Question>itr1=list1.iterator();
	while(itr1.hasNext())
	{
		Question q1=itr1.next();
		System.out.println("qname"+q1.getQname());
		List<Answer>list2=q1.getAnswers();
		Iterator<Answer>itr2=list2.iterator();
		while(itr2.hasNext())
		{
			Answer a=itr2.next();
		
			System.out.println(a.getAname()+":"+a.getPostedby());
		}
		
	}
	session.close();
	System.out.println("success");
	}
}
