import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;



public class Test {
	public static void main(String[] args) {
		Configuration cfg = new Configuration().configure()
				.addAnnotatedClass(Question.class)
				.addAnnotatedClass(Answer.class);
		
		ServiceRegistry sr = new StandardServiceRegistryBuilder()
				.applySettings(cfg.getProperties()).build();
		SessionFactory sf = cfg.buildSessionFactory(sr);
		Session session = sf.openSession();
		Transaction t = session.beginTransaction();
		Answer a1=new Answer();
		a1.setAname("java is secure");
		a1.setPostedby("sam");
		Answer a2=new Answer();
		a2.setAname("java is robust");
		a2.setPostedby("sam");
		Answer a3=new Answer();
		a3.setAname("jsvsscript is clientside scripting");
	a3.setPostedby("dam");
	Answer a4=new Answer();
	a4.setAname("netscape provided it");
	a4.setPostedby("dam");
	List<Answer>list1=new ArrayList<Answer>();
	list1.add(a1);
	list1.add(a2);
	List<Answer>list2=new ArrayList<Answer>();
	list2.add(a3);
	list2.add(a4);
	Question q1=new Question();
	q1.setQname("what is java?");
	q1.setAnswers(list1);
	Question q2=new Question();
	q2.setQname("what is javascript?");
	q2.setAnswers(list2);
	session.persist(q1);
	session.persist(q2);
	t.commit();
	session.close();
		
	
		
		
	}

}
